module calouseIF {
	
	opens main;
	opens controller;
	opens models;
	requires javafx.graphics;
	requires java.sql;
	requires javafx.controls;
	requires javafx.base;
}